def main():
    print("Hello from project!")


if __name__ == "__main__":
    main()
